import pygame 

class Juego:

	def __init__(self):
		print('Inicia...')
		pygame.init()
		pygame.display.set_caption('Juego')
		screen = pygame.display.set_mode((500,500))
		
		a = pygame.image.load('b1.bmp')
		s1 = pygame.image.load('s1.bmp')
		bx = 200
		by = 200
		dx = 0
		dy = 0

		xs = 0

		screen.blit(a, (bx, by))
		screen.blit(s1, (xs, 100)) 

		bandera = False

		reloj = pygame.time.Clock()
		while not bandera:
			if xs >= 0 & xs < 500:
				xs += 1
			if xs == 500:
				xs = 0
			for evento in pygame.event.get():
				if evento.type == pygame.QUIT:
					bandera = True
				if evento.type == pygame.KEYDOWN:
					if evento.key == pygame.K_LEFT:
						dx -= 1
					if evento.key == pygame.K_RIGHT:
						dx += 1
					if evento.key == pygame.K_UP:
						dy -= 1
					if evento.key == pygame.K_DOWN:
						dy += 1
				if evento.type == pygame.KEYUP:
					dx = 0
					dy = 0
			bx += dx
			by += dy
			screen.fill((0,0,0))

			if by == 100:
				print('colision...')
				xs = 0
				audio = pygame.mixer.Sound('efecto.wav')
				audio.play()
				a = pygame.image.load('b2.bmp')
			elif by > 100:
			    a = pygame.image.load('b1.bmp')
			screen.blit(a, (bx, by))
			screen.blit(s1, (xs, 50))
			reloj.tick(2000)
			pygame.display.flip()
		pygame.quit()

if __name__ == '__main__':
	
	juego = Juego()